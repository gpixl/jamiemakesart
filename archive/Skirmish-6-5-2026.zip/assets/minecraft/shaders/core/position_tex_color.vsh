#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    vec3 CameraOffset;
    vec2 ScreenSize;
    float GlintAlpha;
    float GameTime;
    int MenuBlurRadius;
    int UseRgss;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

uniform sampler2D Sampler0;

out vec2 texCoord0;
out vec4 vertexColor;


void main() {

	vec3 pos = Position;


	int id = gl_VertexID % 4;
	vec2 off = vec2(id / 2, clamp(id, 1, 2) == id);

	float rnd = 64;
	float size = (ScreenSize.x / 2) / 3;

	float middleScreen = (ScreenSize.x/2);
	float screenHeight = 1080;
	float wpHeight = 100;


	float uiScale = 0.0;

	if (pos.y > (screenHeight/1)-wpHeight && pos.y < (screenHeight/1)) {
		uiScale = 1.0;
	}

	if (pos.y > (screenHeight/2)-wpHeight && pos.y < (screenHeight/2)) {
		uiScale = 2.0;
	}

	if (pos.y > (screenHeight/3)-wpHeight && pos.y < (screenHeight/3)) {
		uiScale = 3.0;
	}

	if (pos.y > (screenHeight/4)-wpHeight && pos.y < (screenHeight/4)) {
		uiScale = 4.0;
	}

	float verticalOffset = -8;
	float horizontalOffset = middleScreen/uiScale;
	float barOffset = 73;

	vec4 sampleColor = texture(Sampler0, UV0 - off / textureSize(Sampler0, 0));

	float greenOffset = (sampleColor.g * -305) + barOffset;
	


	if (sampleColor.a == 4.0 / 255.0) {
		pos = vec3(horizontalOffset + greenOffset, pos.y + verticalOffset, pos.z);
	}

	if (sampleColor.a == 2.0 / 255.0) {
	    pos = vec3(horizontalOffset + 18.0 + greenOffset, pos.y + verticalOffset, pos.z);
	}

	if (sampleColor.a == 4.0 / 255.0 || sampleColor.a == 2.0 / 255.0) {
		float sinX = sin((greenOffset * 500) + (GameTime * 5000)) * 1;
		pos = vec3(pos.x, pos.y + sinX, pos.z);
	}




	gl_Position = (ProjMat * ModelViewMat * vec4(pos, 1.0));

	texCoord0 = UV0;
	vertexColor = Color;
}
