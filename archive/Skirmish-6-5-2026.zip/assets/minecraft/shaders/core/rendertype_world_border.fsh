#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec3 Pos;

out vec4 fragColor;

void main() {

	float scale = 1.0;
	// vec3 rPos = vec3(round(Pos.x/scale)*scale,round(Pos.y/scale)*scale,round(Pos.z/scale)*scale);
	float sinX = (sin((Pos.x + Pos.z) / 5) / 200) + 1;

    vec4 color = texture(Sampler0, texCoord0);
    if (color.a == 0.0) {
        discard;
    }
	float dist = ((1 - length(Pos)) / 100) + 1;
	float height = dist*2;
	float sinadd = GameTime * 1000;

	float sinR = (sin(((height*10) + sinadd))/1)+0.5;
	float sinG = (sin(((height*7) + sinadd))/1)+0.5;
	float sinB = (sin(((height*15) + sinadd))/1)+0.5;

	vec4 newColor = vec4(sinR, sinG, sinB, color.a * dist * 0.5);

	if (newColor.a <= 0.02) {
        discard;
    }

    fragColor = newColor * ColorModulator;
}
