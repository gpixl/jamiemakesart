#version 330

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }

	float threshold = 0.05;
	float xpR = (126.0/255.0);
	float xpG = (252.0/255.0);
	float xpB = (32.0/255.0);

	bool rC = (color.r >= (xpR - threshold) && color.r <= (xpR + threshold));
	bool gC = (color.g >= (xpG - threshold) && color.g <= (xpG + threshold));
	bool bC = (color.b >= (xpB - threshold) && color.b <= (xpB + threshold));

	float max = 255.0;
	vec4 newColor = vec4(0.0/max,183.0/max,236.0/max,1.0);


	if (rC && gC && bC) {
		color = newColor * ((sin(GameTime * 3000)/5) + 1);
	}

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
